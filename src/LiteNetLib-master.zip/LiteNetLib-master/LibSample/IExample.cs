﻿namespace LibSample
{
    public interface IExample
    {
        void Run();
    }
}
