Information about bug or feature

```csharp
//Some c# code if needed
netPeer.Connect("192.168.0.1", 9050);
```

**Library version**: [commit id (9f2a1d1a8244510d9ec502cc002bfdddba666d09) or release version (0.7.7.1)]

**Framework**: [Mono, Unity, dotnetcore, .NET Framework]

**OS**: [Linux, Windows, etc]
